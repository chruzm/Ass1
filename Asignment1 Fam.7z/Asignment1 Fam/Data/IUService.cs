﻿using LoginExample.Models;
using Models;
namespace Asignment1_Fam.Data
{
    public interface IUService
    {
        User ValidateUser(string userName, string password);
    }
    
}