﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Models;

namespace Asignment1_Fam.Data
{
    public class FamilyJSONData : IFamilyData
    {
        private string famFile = "families.json";
        private IList<Family> families;
        public void writeToJSON()
        {
            string todosAsJson = JsonSerializer.Serialize(families);
            File.WriteAllText(famFile, todosAsJson);
        }
        public void readFromJSON()
        {
            string content = File.ReadAllText(famFile);
            families = JsonSerializer.Deserialize<List<Family>>(content);
        }
        
        public FamilyJSONData()
        {
            if (!File.Exists(famFile))
            {
                writeToJSON();
            }
            else
            {
                readFromJSON();
            }
        }
        public IList<Family> getFamilies()
        {
            List<Family> fm = new List<Family>(families);
            return fm;
        }

        public void Register(Family fam)
        { 
            families.Add(fam);
            writeToJSON();
        }

        public void RemoveFam(string s)
        {
            foreach (var item in families)
            {
                for (int x = 0; x < item.Adults.Count; x++)
                {
                    Family famRemove = families.First(t => t.StreetName+t.HouseNumber == s);
                    families.Remove(famRemove);
                    writeToJSON();
                }
            }
        }

        public Family Get(string s)
        {
            return families.FirstOrDefault(t => t.StreetName == s);
        }
    }
}