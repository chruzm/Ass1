﻿using System.Collections.Generic;
using Models;

namespace Asignment1_Fam.Data
{
    public interface IFamilyData
    {
        IList<Family> getFamilies();
        void Register(Family fam);
        void RemoveFam(string s);
        
    }
}