﻿using System;
using System.Collections.Generic;
using System.Linq;
using Asignment1_Fam.Data;
using LoginExample.Models;
using Models;

namespace LoginExample.Data.Impl {
    public class UserviceDoes : IUService {
        private List<User> users;

        public UserviceDoes() {
            users = new[] {
                new User {
                    City = "Classifed",
                    Domain = "via.dk",
                    Password = "12345",
                    Role = "Agent",
                    BirthYear = 1986,
                    SecurityLevel = 1,
                    UserName = "Testuser1"
                },
                new User {
                    City = "Classifed",
                    Domain = "hotmail.com",
                    Password = "1234",
                    Role = "NSAofficer",
                    BirthYear = 1978,
                    SecurityLevel = 2,
                    UserName = "Testuser2"
                }
            }.ToList();
        }


        public User ValidateUser(string userName, string password) {
            User first = users.FirstOrDefault(user => user.UserName.Equals(userName));
            if (first == null) {
                throw new Exception("User not found");
            }

            if (!first.Password.Equals(password)) {
                throw new Exception("Incorrect password");
            }
            return first;
        }
    }
}